"""
Phase 7.1 — Windowed Temporal EEG Dataset (FINAL, XAI-READY)
-----------------------------------------------------------
✔ One sample = one window
✔ CAP uncertainty preserved (A?)
✔ Variable channels supported
✔ Window index + channel indices exposed
✔ Dataset sanity logging
✔ XAI-ready metadata
"""

from pathlib import Path
from typing import Dict, List, Tuple, Any
import logging

import numpy as np
import torch
from torch.utils.data import Dataset

from . import config


# =============================================================================
# DATASET
# =============================================================================
class TemporalEEGDataset(Dataset):
    """
    One dataset item = ONE temporal window (T, C, F)
    """
    def __init__(
        self,
        overlap: float,
        allowed_subjects=None,
    ):
        self.overlap = overlap
        self.allowed_subjects = allowed_subjects
        self.train_normal_only = config.TRAIN_NORMAL_ONLY

        self.samples: List[Tuple[Path, int]] = []
        self._build_index()

        if len(self.samples) == 0:
            raise RuntimeError(
                f"[Dataset] No windows found for overlap={overlap}"
            )

        self._log_dataset_statistics()
    

    # ------------------------------------------------------------------
    def _build_index(self) -> None:
        overlap_dir = config.DATA_DIR / f"overlap_{int(self.overlap * 100)}"

        if not overlap_dir.exists():
            raise FileNotFoundError(
                f"[Dataset] Missing overlap directory: {overlap_dir}"
            )

        for subj_dir in sorted(overlap_dir.iterdir()):
            if not subj_dir.is_dir():
                continue

            npz_path = subj_dir / "windows.npz"
            if not npz_path.exists():
                continue

            data = np.load(npz_path)
            n_windows = data["features"].shape[0]

            subject_id = subj_dir.name.lower()
            if self.allowed_subjects is not None:
                if subject_id not in self.allowed_subjects:
                    continue

            is_normal = subject_id.startswith("n")

            if self.train_normal_only and not is_normal:
                continue

            for w in range(n_windows):
                self.samples.append((npz_path, w))

    # ------------------------------------------------------------------
    def _log_dataset_statistics(self) -> None:
        cap_counts = np.zeros(len(config.CAP_MAPPING), dtype=int)

        for npz_path, w in self.samples[: min(1000, len(self.samples))]:
            data = np.load(npz_path)
            cap = data["cap"][w]
            for c in cap:
                if 0 <= c < len(cap_counts):
                    cap_counts[c] += 1

        logging.info(
            f"[Dataset] Loaded {len(self.samples)} windows "
            f"(overlap={int(self.overlap * 100)}%)"
        )

        for lbl, idx in config.CAP_MAPPING.items():
            logging.info(
                f"[Dataset] CAP {lbl}: {cap_counts[idx]} frames"
            )

    # ------------------------------------------------------------------
    def __len__(self) -> int:
        return len(self.samples)

    # ------------------------------------------------------------------
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        npz_path, w = self.samples[idx]
        data = np.load(npz_path)

        features = torch.tensor(
            data["features"][w], dtype=torch.float32
        )  # (T, C, F)

        cap = torch.tensor(
            data["cap"][w], dtype=torch.long
        )  # (T,)

        mask = torch.tensor(
            data["mask"][w], dtype=torch.bool
        )  # (T,)

        # ------------------------------------------------------------------
        # SAFETY: CAP range check (A?-aware)
        # ------------------------------------------------------------------
        if not torch.all((cap >= 0) & (cap < len(config.CAP_MAPPING))):
            logging.warning(
                f"[Dataset] Invalid CAP label detected in {npz_path} window {w}"
            )
            cap = cap.clamp(0, len(config.CAP_MAPPING) - 1)

        subject_id = npz_path.parent.name
        label = 0 if subject_id.lower().startswith("n") else 1

        T, C, _ = features.shape

        return {
            "features": features,              # (T, C, F)
            "cap": cap,                        # (T,)
            "mask": mask,                      # (T,)
            "subject_id": subject_id,          # str
            "label": label,                    # int
            "window_idx": w,                   # int  ✅ NEW
            "channel_indices": torch.arange(C) # (C,) ✅ NEW
        }


# =============================================================================
# COLLATE FUNCTION (XAI-SAFE)
# =============================================================================
def collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:

    max_T = max(b["features"].shape[0] for b in batch)
    max_C = max(b["features"].shape[1] for b in batch)
    F = batch[0]["features"].shape[-1]

    feats, caps, masks = [], [], []
    subject_ids, labels, lengths, window_idxs = [], [], [], []

    for b in batch:
        T, C, _ = b["features"].shape

        feat = torch.zeros(max_T, max_C, F)
        cap = torch.zeros(max_T, dtype=torch.long)
        mask = torch.zeros(max_T, dtype=torch.bool)

        feat[:T, :C] = b["features"]
        cap[:T] = b["cap"]
        mask[:T] = True

        feats.append(feat)
        caps.append(cap)
        masks.append(mask)

        subject_ids.append(b["subject_id"])
        labels.append(b["label"])
        lengths.append(T)
        window_idxs.append(b["window_idx"])

    return {
        "features": torch.stack(feats),    # (B, T, C, F)
        "cap": torch.stack(caps),
        "mask": torch.stack(masks),
        "labels": torch.tensor(labels),
        "subject_ids": subject_ids,
        "lengths": torch.tensor(lengths),
        "window_idxs": torch.tensor(window_idxs),  # ✅ NEW
    }