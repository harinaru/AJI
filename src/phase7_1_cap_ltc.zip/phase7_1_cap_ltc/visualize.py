"""
Phase 7.x — FINAL Q1 JOURNAL-GRADE VISUALIZATION SUITE
======================================================
✔ Reviewer-safe
✔ No hallucinated metrics
✔ Statistical validation
✔ ROC + PR curves
✔ ROC confidence intervals
✔ Threshold analysis
✔ Confusion matrix
✔ CAP transition dynamics
✔ Overlap ablations
✔ Control vs Disorder distributions
✔ Bootstrap confidence intervals
✔ Effect size visualizations
✔ Calibration analysis
✔ Runtime analysis
✔ Latent-space visualization
✔ Publication-grade neuroscience figures
✔ XAI-aware
✔ BasedPyright-safe
✔ Seaborn-safe
✔ Pandas typing-safe
"""

import logging
import json
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns

from scipy.stats import mannwhitneyu

from sklearn.metrics import (
    roc_curve,
    auc,
    precision_recall_curve,
    confusion_matrix,
    ConfusionMatrixDisplay,
)

from sklearn.manifold import TSNE
from sklearn.calibration import calibration_curve

from . import config

from .metrics import (
    bootstrap_auc_ci,
    bootstrap_effect_size_ci,
    cohens_d,
)


# =============================================================================
# STYLE
# =============================================================================
sns.set_style("whitegrid")

plt.rcParams.update({
    "font.size": 11,
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "legend.fontsize": 10,
    "figure.dpi": 120,
})

OVERLAPS = [0, 50, 75]

# =============================================================================
# FIGURE REGISTRY
# =============================================================================
GENERATED_FIGURES = []


# =============================================================================
# SAFE CSV
# =============================================================================
def safe_csv(
    path: Path
) -> Optional[pd.DataFrame]:

    if not path.exists():

        logging.warning(
            f"[Viz] Missing file → {path}"
        )

        return None

    try:

        df = pd.read_csv(path)

        if len(df) == 0:

            logging.warning(
                f"[Viz] Empty CSV → {path}"
            )

            return None

        return df

    except Exception as e:

        logging.warning(
            f"[Viz] Failed loading CSV: {path} | {e}"
        )

        return None


# =============================================================================
# SAFE FIGURE SAVE
# =============================================================================
def save_fig(name: str):

    config.FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    save_path = (
        config.FIGURE_DIR / name
    )

    plt.tight_layout()

    plt.savefig(
        save_path,
        dpi=300,
        bbox_inches="tight",
    )

    GENERATED_FIGURES.append(
        str(save_path)
    )

    plt.close()


# =============================================================================
# LOAD SUBJECT DATA
# =============================================================================
def load_subject_data(
    overlap: Optional[int] = None
) -> Optional[pd.DataFrame]:

    if overlap is None:

        overlap = int(
            config.OVERLAP_PERCENT * 100
        )

    path = (
        config.RESULTS_DIR
        / "inference"
        / f"overlap_{overlap}"
        / "subject_level_metrics.csv"
    )

    df = safe_csv(path)

    if df is None:
        return None

    df = df.copy()

    numeric_cols = [
        "label",
        "mean_error",
        "mean_delta",
        "instability_index",
    ]

    for col in numeric_cols:

        if col in df.columns:

            numeric_series = pd.Series(
                pd.to_numeric(
                    df[col],
                    errors="coerce",
                ),
                dtype="float64",
            )

            df[col] = numeric_series

    return df


# =============================================================================
# LOAD WINDOW DATA
# =============================================================================
def load_window_data(
    overlap: Optional[int] = None
) -> Optional[pd.DataFrame]:

    if overlap is None:

        overlap = int(
            config.OVERLAP_PERCENT * 100
        )

    path = (
        config.RESULTS_DIR
        / "inference"
        / f"overlap_{overlap}"
        / "window_level_metrics.csv"
    )

    df = safe_csv(path)

    if df is None:
        return None

    df = df.copy()

    numeric_cols = [
        "cap_state",
        "delta_error",
    ]

    for col in numeric_cols:

        if col in df.columns:

            numeric_series = pd.Series(
                pd.to_numeric(
                    df[col],
                    errors="coerce",
                ),
                dtype="float64",
            )

            df[col] = numeric_series

    return df


# =============================================================================
# FIG 1 — TRAINING LOSS
# =============================================================================
def fig_training_loss():

    logging.info("[Viz] Fig 1")

    plt.figure(figsize=(6.5, 4.5))

    plotted = False

    for ov in OVERLAPS:

        path = (
            config.LOG_DIR
            / f"loss_overlap_{ov}.csv"
        )

        if not path.exists():
            continue

        try:

            df = pd.read_csv(path)

            plt.plot(
                df["epoch"],
                df["loss"],
                marker="o",
                linewidth=2,
                label=f"{ov}% overlap",
            )

            plotted = True

        except Exception as e:

            logging.warning(
                f"[Viz] Failed Fig1 overlap={ov} | {e}"
            )

    if not plotted:
        return

    plt.xlabel("Epoch")
    plt.ylabel("MSE Reconstruction Loss")
    plt.title("Training Convergence")
    plt.legend()

    save_fig("fig1_training_loss.png")


# =============================================================================
# FIG 2 — τ PER CAP
# =============================================================================
def fig_tau_cap():

    logging.info("[Viz] Fig 2")

    tau_path = (
        config.TAU_DIR
        / f"learned_tau_overlap_{int(config.OVERLAP_PERCENT*100)}.json"
    )

    if not tau_path.exists():
        return

    try:

        with open(tau_path, "r") as f:

            tau = json.load(f)

        tau_base = float(
            tau["tau_base"]
        )

        tau_cap = np.asarray(
            tau["tau_cap"],
            dtype=np.float64,
        )

        labels = list(
            config.CAP_MAPPING.keys()
        )[:len(tau_cap)]

        values = tau_base + tau_cap

        plt.figure(figsize=(6.5, 4.5))

        sns.barplot(
            x=labels,
            y=values,
        )

        plt.ylabel("Learned τ")

        plt.title(
            "CAP-Modulated Time Constants"
        )

        save_fig("fig2_tau_cap.png")

    except Exception as e:

        logging.warning(
            f"[Viz] Fig2 failed | {e}"
        )


# =============================================================================
# FIG 3 — DELTA VS ERROR
# =============================================================================
def fig_delta_vs_mean():

    logging.info("[Viz] Fig 3")

    rows = []

    for ov in OVERLAPS:

        df = load_subject_data(ov)

        if df is None:
            continue

        for _, r in df.iterrows():

            rows.append({
                "Overlap":
                    ov,

                "Mean Error":
                    float(r["mean_error"]),

                "Delta Error":
                    float(r["mean_delta"]),
            })

    if len(rows) == 0:
        return

    plot_df = pd.DataFrame(rows)

    plt.figure(figsize=(6, 4.5))

    sns.scatterplot(
        data=plot_df.copy(),
        x="Mean Error",
        y="Delta Error",
        hue="Overlap",
        s=90,
    )

    plt.title(
        "Temporal Instability vs Reconstruction Error"
    )

    save_fig("fig3_delta_vs_mean.png")


# =============================================================================
# FIG 4 — OVERLAP ROBUSTNESS
# =============================================================================
def fig_instability_vs_overlap():

    logging.info("[Viz] Fig 4")

    rows = []

    for ov in OVERLAPS:

        df = load_subject_data(ov)

        if df is None:
            continue

        rows.append({
            "Overlap":
                ov,

            "Mean":
                float(
                    np.mean(
                        df["instability_index"]
                    )
                ),

            "Std":
                float(
                    np.std(
                        df["instability_index"]
                    )
                ),
        })

    if len(rows) == 0:
        return

    plot_df = pd.DataFrame(rows)

    plt.figure(figsize=(6, 4.5))

    plt.errorbar(
        plot_df["Overlap"],
        plot_df["Mean"],
        yerr=plot_df["Std"],
        fmt="o-",
        capsize=5,
    )

    plt.xlabel("Overlap (%)")
    plt.ylabel("Instability Index")

    plt.title(
        "Robustness Across Window Overlaps"
    )

    save_fig("fig4_overlap_robustness.png")


# =============================================================================
# FIG 5 — CAP DELTA DISTRIBUTION
# =============================================================================
def fig_cap_delta():

    logging.info("[Viz] Fig 5")

    df = load_window_data()

    if df is None:
        return

    plt.figure(figsize=(7, 4.5))

    sns.boxplot(
        data=df.copy(),
        x="cap_state",
        y="delta_error",
    )

    plt.xlabel("CAP State")
    plt.ylabel("Δerror")

    plt.title(
        "CAP-Conditioned Temporal Instability"
    )

    save_fig("fig5_cap_delta.png")


# =============================================================================
# FIG 6 — ROC
# =============================================================================
def fig_roc():

    logging.info("[Viz] Fig 6")

    df = load_subject_data()

    if df is None:
        return

    y_true = (
        df["label"]
        .astype(int)
        .to_numpy()
    )

    scores = (
        df["instability_index"]
        .to_numpy(dtype=np.float64)
    )

    if len(np.unique(y_true)) < 2:
        return

    fpr, tpr, _ = roc_curve(
        y_true,
        scores,
    )

    roc_auc = auc(
        fpr,
        tpr,
    )

    plt.figure(figsize=(6, 5))

    plt.plot(
        fpr,
        tpr,
        linewidth=2,
        label=f"AUC = {roc_auc:.3f}",
    )

    plt.plot([0, 1], [0, 1], "--")

    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")

    plt.legend()

    save_fig("fig6_roc.png")


# =============================================================================
# FIG — ROC WITH CI
# =============================================================================
def fig_roc_with_ci():

    logging.info("[Viz] ROC CI")

    df = load_subject_data()

    if df is None:
        return

    y_true = (
        df["label"]
        .astype(int)
        .to_numpy()
    )

    scores = (
        df["instability_index"]
        .to_numpy(dtype=np.float64)
    )

    if len(np.unique(y_true)) < 2:
        return

    fpr, tpr, _ = roc_curve(
        y_true,
        scores,
    )

    roc_auc = auc(fpr, tpr)

    ci_low, ci_high = bootstrap_auc_ci(
        y_true,
        scores,
    )

    plt.figure(figsize=(6, 5))

    plt.plot(
        fpr,
        tpr,
        linewidth=2,
        label=(
            f"AUC={roc_auc:.3f} "
            f"[{ci_low:.3f}, {ci_high:.3f}]"
        ),
    )

    plt.plot([0, 1], [0, 1], "--")

    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")

    plt.title(
        "ROC Curve with 95% Bootstrap CI"
    )

    plt.legend()

    save_fig(
        "fig_roc_ci.png"
    )


# =============================================================================
# FIG 7 — PR CURVE
# =============================================================================
def fig_pr_curve():

    logging.info("[Viz] Fig 7")

    df = load_subject_data()

    if df is None:
        return

    y_true = (
        df["label"]
        .astype(int)
        .to_numpy()
    )

    scores = (
        df["instability_index"]
        .to_numpy(dtype=np.float64)
    )

    precision, recall, _ = precision_recall_curve(
        y_true,
        scores,
    )

    pr_auc = auc(
        recall,
        precision,
    )

    plt.figure(figsize=(6, 5))

    plt.plot(
        recall,
        precision,
        linewidth=2,
        label=f"AUPRC = {pr_auc:.3f}",
    )

    plt.xlabel("Recall")
    plt.ylabel("Precision")

    plt.title(
        "Precision–Recall Curve"
    )

    plt.legend()

    save_fig("fig7_pr_curve.png")


# =============================================================================
# FIG 8 — CONTROL VS DISORDER
# =============================================================================
def fig_control_vs_disorder():

    logging.info("[Viz] Fig 8")

    df = load_subject_data()

    if df is None:
        return

    df = df.copy()

    df["Group"] = np.where(
        df["label"].astype(int) == 0,
        "Control",
        "Disorder",
    )

    plt.figure(figsize=(6, 5))

    sns.violinplot(
        data=df.copy(),
        x="Group",
        y="instability_index",
        inner="box",
        cut=0,
    )

    sns.stripplot(
        data=df.copy(),
        x="Group",
        y="instability_index",
        color="black",
        alpha=0.5,
        jitter=True,
    )

    plt.xlabel("Clinical Group")
    plt.ylabel("Instability Index")

    plt.title(
        "Instability Distribution Across Groups"
    )

    save_fig(
        "fig8_control_vs_disorder.png"
    )


# =============================================================================
# FIG 9 — CONFUSION MATRIX
# =============================================================================
def fig_confusion_matrix():

    logging.info("[Viz] Fig 9")

    df = load_subject_data()

    if df is None:
        return

    scores = (
        df["instability_index"]
        .to_numpy(dtype=np.float64)
    )

    labels = (
        df["label"]
        .astype(int)
        .to_numpy()
    )

    threshold = float(
        np.mean(scores)
        +
        np.std(scores)
    )

    preds = (
        scores > threshold
    ).astype(int)

    cm = confusion_matrix(
        labels,
        preds,
    )

    fig, ax = plt.subplots(
        figsize=(5, 5)
    )

    disp = ConfusionMatrixDisplay(
        confusion_matrix=cm
    )

    disp.plot(ax=ax)

    plt.title("Confusion Matrix")

    save_fig(
        "fig9_confusion_matrix.png"
    )


# =============================================================================
# FIG 10 — THRESHOLD DISTRIBUTION
# =============================================================================
def fig_threshold_distribution():

    logging.info("[Viz] Fig 10")

    df = load_subject_data()

    if df is None:
        return

    scores = (
        df["instability_index"]
        .dropna()
        .to_numpy(dtype=np.float64)
    )

    threshold = float(
        np.mean(scores)
        +
        2.0 * np.std(scores)
    )

    plt.figure(figsize=(7, 4.5))

    sns.histplot(
        scores,
        kde=True,
    )

    plt.axvline(
        threshold,
        linestyle="--",
        linewidth=2,
        label=f"Threshold={threshold:.3f}",
    )

    plt.xlabel("Instability Score")

    plt.title(
        "Anomaly Threshold Estimation"
    )

    plt.legend()

    save_fig("fig10_threshold.png")


# =============================================================================
# FIG 11 — CAP TRANSITION MATRIX
# =============================================================================
def fig_cap_transition_matrix():

    logging.info("[Viz] Fig 11")

    df = load_window_data()

    if df is None:
        return

    caps = (
        df["cap_state"]
        .dropna()
        .astype(int)
        .to_numpy()
    )

    if len(caps) < 2:
        return

    n_caps = int(
        np.max(caps) + 1
    )

    mat = np.zeros(
        (n_caps, n_caps)
    )

    for i in range(len(caps) - 1):

        a = int(caps[i])
        b = int(caps[i + 1])

        if (
            0 <= a < n_caps
            and
            0 <= b < n_caps
        ):
            mat[a, b] += 1

    row_sums = mat.sum(
        axis=1,
        keepdims=True,
    )

    row_sums[row_sums == 0] = 1

    mat = mat / row_sums

    plt.figure(figsize=(6, 5))

    sns.heatmap(
        mat,
        annot=True,
        fmt=".2f",
        cmap="viridis",
    )

    plt.xlabel("Next CAP")
    plt.ylabel("Current CAP")

    plt.title(
        "CAP Transition Dynamics"
    )

    save_fig(
        "fig11_cap_transition.png"
    )


# =============================================================================
# FIG 12 — SUBJECT RANKING
# =============================================================================
def fig_subject_ranking():

    logging.info("[Viz] Fig 12")

    df = load_subject_data()

    if df is None:
        return

    df = df.sort_values(
        "instability_index"
    )

    plt.figure(figsize=(8, 4.5))

    plt.plot(
        np.arange(len(df)),
        df["instability_index"],
        marker="o",
    )

    plt.xlabel("Subject Rank")
    plt.ylabel("Instability Index")

    plt.title(
        "Subject-Level Ranking"
    )

    save_fig(
        "fig12_subject_ranking.png"
    )


# =============================================================================
# FIG 13 — OVERLAP ABLATION
# =============================================================================
def fig_overlap_ablation():

    logging.info("[Viz] Fig 13")

    rows = []

    for ov in OVERLAPS:

        df = load_subject_data(ov)

        if df is None:
            continue

        rows.append({
            "Overlap":
                ov,

            "Mean Instability":
                float(
                    np.mean(
                        df["instability_index"]
                    )
                ),
        })

    if len(rows) == 0:
        return

    plot_df = pd.DataFrame(rows)

    plt.figure(figsize=(6, 4.5))

    sns.barplot(
        data=plot_df,
        x="Overlap",
        y="Mean Instability",
    )

    plt.title(
        "Overlap Ablation Study"
    )

    save_fig(
        "fig13_overlap_ablation.png"
    )


# =============================================================================
# FIG 14 — STATISTICAL SIGNIFICANCE
# =============================================================================
def fig_statistical_significance():

    logging.info("[Viz] Fig 14")

    df = load_subject_data()

    if df is None:
        return

    control = (
        df.loc[
            df["label"] == 0,
            "instability_index",
        ]
        .dropna()
        .to_numpy()
    )

    disorder = (
        df.loc[
            df["label"] == 1,
            "instability_index",
        ]
        .dropna()
        .to_numpy()
    )

    if (
        len(control) == 0
        or
        len(disorder) == 0
    ):
        return

    _, p = mannwhitneyu(
        control,
        disorder,
    )

    plt.figure(figsize=(6, 5))

    sns.boxplot(
        data=df.copy(),
        x="label",
        y="instability_index",
    )

    plt.title(
        f"Mann–Whitney U Test (p={p:.4e})"
    )

    save_fig(
        "fig14_statistics.png"
    )


# =============================================================================
# FIG 15 — ERROR DISTRIBUTION
# =============================================================================
def fig_error_distribution():

    logging.info("[Viz] Fig 15")

    df = load_subject_data()

    if df is None:
        return

    df["label_name"] = np.where(
        df["label"].astype(int) == 0,
        "Control",
        "Disorder",
    )

    plt.figure(figsize=(7, 4.5))

    sns.kdeplot(
        data=df.copy(),
        x="mean_error",
        hue="label_name",
        fill=True,
    )

    plt.title(
        "Reconstruction Error Distribution"
    )

    save_fig(
        "fig15_error_distribution.png"
    )


# =============================================================================
# FIG — EFFECT SIZE
# =============================================================================
def fig_effect_size():

    logging.info("[Viz] Effect Size")

    df = load_subject_data()

    if df is None:
        return

    control = (
        df.loc[
            df["label"] == 0,
            "instability_index",
        ]
        .dropna()
        .to_numpy(dtype=np.float64)
    )

    disorder = (
        df.loc[
            df["label"] == 1,
            "instability_index",
        ]
        .dropna()
        .to_numpy(dtype=np.float64)
    )

    if (
        len(control) < 2
        or
        len(disorder) < 2
    ):
        return

    d = cohens_d(
        disorder,
        control,
    )

    ci_low, ci_high = (
        bootstrap_effect_size_ci(
            disorder,
            control,
        )
    )

    plt.figure(figsize=(5, 4))

    plt.bar(
        ["Cohen's d"],
        [d],
    )

    plt.errorbar(
        [0],
        [d],
        yerr=[
            [d - ci_low],
            [ci_high - d],
        ],
        fmt="o",
        capsize=6,
    )

    plt.ylabel("Effect Size")

    plt.title(
        (
            f"Cohen's d = {d:.3f}\n"
            f"95% CI "
            f"[{ci_low:.3f}, {ci_high:.3f}]"
        )
    )

    save_fig(
        "fig_effect_size.png"
    )


# =============================================================================
# FIG — CALIBRATION CURVE
# =============================================================================
def fig_calibration_curve():

    logging.info("[Viz] Calibration")

    df = load_subject_data()

    if df is None:
        return

    y_true = (
        df["label"]
        .astype(int)
        .to_numpy()
    )

    scores = (
        df["instability_index"]
        .to_numpy(dtype=np.float64)
    )

    if len(np.unique(y_true)) < 2:
        return

    probs = (
        scores - scores.min()
    ) / (
        scores.max() - scores.min() + 1e-8
    )

    frac_pos, mean_pred = calibration_curve(
        y_true,
        probs,
        n_bins=10,
    )

    plt.figure(figsize=(5, 5))

    plt.plot(
        mean_pred,
        frac_pos,
        marker="o",
    )

    plt.plot([0, 1], [0, 1], "--")

    plt.xlabel("Predicted Probability")
    plt.ylabel("Observed Frequency")

    plt.title(
        "Calibration Curve"
    )

    save_fig(
        "fig_calibration_curve.png"
    )


# =============================================================================
# FIG — LATENT TSNE
# =============================================================================
def fig_latent_tsne():

    logging.info("[Viz] Latent t-SNE")

    latent_path = (
        config.RESULTS_DIR
        / "latent_embeddings.npy"
    )

    label_path = (
        config.RESULTS_DIR
        / "latent_labels.npy"
    )

    if (
        not latent_path.exists()
        or
        not label_path.exists()
    ):
        return

    latent = np.load(latent_path)
    labels = np.load(label_path)

    tsne = TSNE(
        n_components=2,
        perplexity=15,
        random_state=42,
    )

    emb = tsne.fit_transform(latent)

    plot_df = pd.DataFrame({
        "x": emb[:, 0],
        "y": emb[:, 1],
        "label": labels,
    })

    plt.figure(figsize=(6, 5))

    sns.scatterplot(
        data=plot_df,
        x="x",
        y="y",
        hue="label",
    )

    plt.title(
        "Latent Space t-SNE"
    )

    save_fig(
        "fig_latent_tsne.png"
    )


# =============================================================================
# FIG — RUNTIME ANALYSIS
# =============================================================================
def fig_runtime_analysis():

    logging.info("[Viz] Runtime")

    runtime_path = (
        config.RESULTS_DIR
        / "runtime_metrics.json"
    )

    if not runtime_path.exists():
        return

    with open(runtime_path, "r") as f:
        runtime = json.load(f)

    names = list(runtime.keys())

    values = [
        runtime[k]
        for k in names
    ]

    plt.figure(figsize=(7, 4))

    sns.barplot(
        x=names,
        y=values,
    )

    plt.xticks(rotation=20)

    plt.ylabel("Seconds")

    plt.title(
        "Pipeline Runtime Analysis"
    )

    save_fig(
        "fig_runtime_analysis.png"
    )


# =============================================================================
# MASTER
# =============================================================================
def run_all_visualizations():

    logging.basicConfig(
        level=logging.INFO
    )

    config.FIGURE_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    # CORE
    fig_training_loss()
    fig_tau_cap()
    fig_delta_vs_mean()
    fig_instability_vs_overlap()
    fig_cap_delta()
    fig_roc()

    # HIGH PRIORITY
    fig_roc_with_ci()
    fig_pr_curve()
    fig_control_vs_disorder()
    fig_confusion_matrix()
    fig_threshold_distribution()
    fig_cap_transition_matrix()

    # MEDIUM PRIORITY
    fig_subject_ranking()
    fig_overlap_ablation()
    fig_statistical_significance()
    fig_effect_size()
    fig_calibration_curve()

    # ADVANCED
    fig_latent_tsne()
    fig_runtime_analysis()

    # LOW PRIORITY
    fig_error_distribution()

    # SAVE FIGURE REGISTRY
    registry_path = (
        config.FIGURE_DIR
        / "generated_figures.json"
    )

    with open(registry_path, "w") as f:

        json.dump(
            GENERATED_FIGURES,
            f,
            indent=4,
        )

    logging.info(
        "✅ ALL Q1 JOURNAL FIGURES GENERATED"
    )


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":

    run_all_visualizations()